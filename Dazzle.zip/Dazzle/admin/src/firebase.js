// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCsHGLXVaNtMG1DicGl7-lmVcVcx9HaWGw",
  authDomain: "dazzle-a4d27.firebaseapp.com",
  projectId: "dazzle-a4d27",
  storageBucket: "dazzle-a4d27.appspot.com",
  messagingSenderId: "237899290832",
  appId: "1:237899290832:web:e7dfbd73ff14f7bd72a6d5"
};

// Initialize Firebase
const applic = initializeApp(firebaseConfig);


export default applic;